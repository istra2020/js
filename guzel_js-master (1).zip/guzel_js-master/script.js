let money=1; 
let income=2; 
let addExpenses=3; 
let deposit=4; 
let mission='text'; 
let period=6;
alert('изменение');
console.log('всё получится');